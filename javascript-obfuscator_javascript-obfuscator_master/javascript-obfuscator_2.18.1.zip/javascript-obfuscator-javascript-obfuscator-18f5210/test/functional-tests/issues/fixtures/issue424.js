!function () {
    {
        let name;
    }
    {
        let {name} = {name: "foo"};
        console.log(name);
    }
}();