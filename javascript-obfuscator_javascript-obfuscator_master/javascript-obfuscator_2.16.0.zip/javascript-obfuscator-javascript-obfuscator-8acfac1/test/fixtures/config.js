module.exports = {
	compact: true,
    exclude: ['**/foo.js'],
	selfDefending: false,
	sourceMap: true
};