export type TTypeFromEnum<T extends object> = (T)[keyof T];
