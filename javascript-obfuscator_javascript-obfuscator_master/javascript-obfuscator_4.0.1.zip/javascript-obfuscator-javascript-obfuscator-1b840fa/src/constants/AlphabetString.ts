export const alphabetString: string = 'abcdefghijklmnopqrstuvwxyz';
