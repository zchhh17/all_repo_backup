import * as ESTree from 'estree';

export type TNodeWithLexicalScopeStatements = ESTree.Program | ESTree.BlockStatement;
