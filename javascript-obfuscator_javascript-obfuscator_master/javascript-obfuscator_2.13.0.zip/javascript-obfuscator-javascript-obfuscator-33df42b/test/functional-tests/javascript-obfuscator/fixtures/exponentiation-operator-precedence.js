var foo = (1-2) ** 2;
