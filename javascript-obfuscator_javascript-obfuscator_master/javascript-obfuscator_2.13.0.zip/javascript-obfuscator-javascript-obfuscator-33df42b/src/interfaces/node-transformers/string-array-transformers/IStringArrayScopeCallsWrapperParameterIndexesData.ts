export interface IStringArrayScopeCallsWrapperParameterIndexesData {
    /**
     * @type {number}
     */
    valueIndexParameterIndex: number;

    /**
     * @type {number}
     */
    decodeKeyParameterIndex: number;
}
