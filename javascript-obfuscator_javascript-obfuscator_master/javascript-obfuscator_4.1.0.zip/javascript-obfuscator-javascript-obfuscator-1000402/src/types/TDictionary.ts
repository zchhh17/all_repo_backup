/* eslint-disable @typescript-eslint/consistent-type-definitions */

export type TDictionary <T = unknown> = {[key: string]: T};
