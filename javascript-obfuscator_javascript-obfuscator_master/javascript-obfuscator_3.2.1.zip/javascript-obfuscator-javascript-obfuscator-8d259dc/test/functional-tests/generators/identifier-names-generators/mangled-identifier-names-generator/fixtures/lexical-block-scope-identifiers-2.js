var foo = 'abc';
function bar (hawk, bark) {
    function pig (dog, cat) {}
    function bird (duck, bear) {}
}
function baz (eagle, cow) {
    function rabbit (mouse, lion) {}
    function bird (tiger, kiwi) {}
}