export type TScopeIdentifiersTraverserCallback <TData> = (data: TData) => void;
