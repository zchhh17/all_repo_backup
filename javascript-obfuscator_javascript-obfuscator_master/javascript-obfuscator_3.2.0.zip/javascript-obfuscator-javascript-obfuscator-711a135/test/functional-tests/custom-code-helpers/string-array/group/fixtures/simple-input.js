var foo = 'foo';
var bar = 'bar';
var baz = 'baz';
