/// <reference path="../../src/declarations/escodegen.d.ts" />
/// <reference path="../../src/declarations/ESTree.d.ts" />
/// <reference path="./source-map-resolve.d.ts" />