function f(obj) {
    const {c} = obj;
}
