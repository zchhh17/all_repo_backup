export enum VisitorDirection {
    Enter = 'enter',
    Leave = 'leave'
}
