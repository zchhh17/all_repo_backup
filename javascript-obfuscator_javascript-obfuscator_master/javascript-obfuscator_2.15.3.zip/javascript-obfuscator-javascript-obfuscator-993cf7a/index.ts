"use strict";

import { JavaScriptObfuscator } from './src/JavaScriptObfuscatorFacade';

module.exports = JavaScriptObfuscator;
