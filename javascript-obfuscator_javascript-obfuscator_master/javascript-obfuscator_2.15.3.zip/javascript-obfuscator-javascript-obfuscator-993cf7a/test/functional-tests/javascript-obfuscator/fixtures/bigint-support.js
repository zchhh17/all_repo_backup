function test() {
    return 9007199254740993n + 10n + 0xan;
}