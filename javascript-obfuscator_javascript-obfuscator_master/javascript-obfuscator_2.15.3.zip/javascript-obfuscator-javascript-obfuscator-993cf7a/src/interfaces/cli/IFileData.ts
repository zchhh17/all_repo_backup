export interface IFileData {
    filePath: string;
    content: string;
}
