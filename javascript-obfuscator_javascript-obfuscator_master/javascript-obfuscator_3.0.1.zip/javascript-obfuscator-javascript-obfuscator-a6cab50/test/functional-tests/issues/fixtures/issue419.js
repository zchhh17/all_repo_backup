async function test(params) {
    for await (let param of params) {}
}
