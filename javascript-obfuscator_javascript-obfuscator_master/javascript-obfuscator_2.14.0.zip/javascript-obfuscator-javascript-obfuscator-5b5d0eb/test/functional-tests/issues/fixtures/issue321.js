function e() {
    function e() {
    }
    e();
}

(function() {
    e();
})();
