export enum ObjectExpressionKeysTransformerCustomNode {
    ObjectExpressionVariableDeclarationHostNode =
        'ObjectExpressionVariableDeclarationHostNode'
}
