/* eslint-disable */

declare namespace NodeJS {
    export interface ProcessEnv {
        VERSION?: string;
        BUILD_TIMESTAMP?: string;
    }
}