export enum CodeTransformationStage {
    PreparingTransformers = 'PreparingTransformers',
    FinalizingTransformers = 'FinalizingTransformers',
}
