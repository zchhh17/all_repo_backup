/**
 * @returns {string}
 */
export function StringArrayTemplate (): string {
    return `
        const {stringArrayName} = [{stringArrayStorageItems}];
    `;
}
