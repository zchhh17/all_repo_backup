(function () {
    var test = 'test';
})();