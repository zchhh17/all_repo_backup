export enum DeadCodeInjectionCustomNode {
    BlockStatementDeadCodeInjectionNode = 'BlockStatementDeadCodeInjectionNode'
}
