function foo () {
    const testA = 'first';
    const testB = 'abc';
}