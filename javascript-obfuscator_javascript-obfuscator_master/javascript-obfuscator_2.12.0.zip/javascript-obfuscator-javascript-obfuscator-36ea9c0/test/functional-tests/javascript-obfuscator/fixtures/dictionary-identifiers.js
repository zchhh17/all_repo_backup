(function () {
    var test1 = 1;
    var test2 = 2;
    var test3 = 3;
    var test4 = 4;
    var test5 = 5;
    var test6 = 6;
})();