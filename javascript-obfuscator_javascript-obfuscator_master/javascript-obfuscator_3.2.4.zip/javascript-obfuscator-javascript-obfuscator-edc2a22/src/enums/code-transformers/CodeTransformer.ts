export enum CodeTransformer {
    HashbangOperatorTransformer = 'HashbangOperatorTransformer'
}
