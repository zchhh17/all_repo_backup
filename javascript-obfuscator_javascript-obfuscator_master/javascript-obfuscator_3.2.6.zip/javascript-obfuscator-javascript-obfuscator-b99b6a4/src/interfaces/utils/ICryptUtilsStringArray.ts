/* eslint-disable @typescript-eslint/no-empty-interface */
import { ICryptUtils } from './ICryptUtils';

export interface ICryptUtilsStringArray extends ICryptUtils {}
