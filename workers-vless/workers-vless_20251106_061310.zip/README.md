# Workers-Vless

根据mingyu的snippets版本结合天书大佬的控流用AI改的，限速24M

* 群聊: [HeroCore](https://t.me/HeroCore)
* 频道: [HeroMsg](https://t.me/HeroMsg)


  * `/s=admin:123456@123.123.28.123:13333`（仅SOCKS5）
  * `/gs=admin:123456@123.123.28.123:13333`（全局SOCKS5）
  * `/p=ProxyIP.US.CMLiussss.net`（仅Proxyip）
