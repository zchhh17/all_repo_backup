> ip-query.js是部署在Cloudflare  workers 用于查询ip的工具，从多个api查询，用于参考，复制到workers直接部署即可。
<img width="2350" height="1074" alt="image" src="https://github.com/user-attachments/assets/b7295a04-5053-45c5-92f7-78ae7dfa5a45" />
