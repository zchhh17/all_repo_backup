/*
手搓节点使用说明如下：
	一、本程序预设：
		userID=f1a50f1c-e751-4d62-83aa-926a7ae32955（强烈建议部署时更换）;
	二、v2rayN客户端的单节点路径设置代理ip，通过代理客户端路径传递
		1、socks5代理cf相关的网站，非cf相关的网站走直连,格式：socks5=xxx或者socks5://xxx
		2、proxyip代理cf相关的网站，非cf相关的网站走直连,格式：pyip=xxx或者proxyip=xxx
		两种任选其一，如果不设置留空，cf相关的网站无法访问;
	注意：workers、pages、snippets都可以部署，部署完后手搓443系6个端口节点vless+ws+tls
*/

import { connect } from "cloudflare:sockets";

const userID = "f1a50f1c-e751-4d62-83aa-926a7ae32955";

function createWebSocketReadableStream(ws, earlyDataHeader) {
	return new ReadableStream({
		start(controller) {
			ws.addEventListener('message', event => {
				controller.enqueue(event.data);
			});
			ws.addEventListener('close', () => {
				controller.close();
			});
			ws.addEventListener('error', err => {
				controller.error(err);
			});
			if (earlyDataHeader) {
				try {
					const decoded = atob(earlyDataHeader.replace(/-/g, '+').replace(/_/g, '/'));
					const data = Uint8Array.from(decoded, c => c.charCodeAt(0));
					controller.enqueue(data.buffer);
				} catch (e) {
					console.error("Error decoding early data:", e);
					controller.error(e);
				}
			}
		},
		cancel(reason) {
			console.log('ReadableStream cancelled', reason);
			ws.close();
		}
	});
}

function formatUUID(bytes) {
	const hex = Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('');
	return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}

function parsewaliexiHeader(buffer, userID) {
	if (buffer.byteLength < 24) {
		return { hasError: true, message: 'Invalid header length' };
	}
	const view = new DataView(buffer);
	const version = new Uint8Array(buffer.slice(0, 1));
	const uuid = formatUUID(new Uint8Array(buffer.slice(1, 17)));
	if (uuid !== userID) {
		return { hasError: true, message: 'Invalid user' };
	}
	const optionsLength = view.getUint8(17);
	const command = view.getUint8(18 + optionsLength);
	if (command === 1) {
	} else {
		return { hasError: true, message: 'Unsupported command, only TCP(01) is supported' };
	}
	let offset = 19 + optionsLength;
	const port = view.getUint16(offset);
	offset += 2;
	const addressType = view.getUint8(offset++);
	let address = '';
	switch (addressType) {
		case 1: // IPv4
			address = Array.from(new Uint8Array(buffer.slice(offset, offset + 4))).join('.');
			offset += 4;
			break;
		case 2: // Domain name
			const domainLength = view.getUint8(offset++);
			address = new TextDecoder().decode(buffer.slice(offset, offset + domainLength));
			offset += domainLength;
			break;
		case 3: // IPv6
			const ipv6 = [];
			for (let i = 0; i < 8; i++) {
				ipv6.push(view.getUint16(offset).toString(16).padStart(4, '0'));
				offset += 2;
			}
			address = ipv6.join(':').replace(/(^|:)0+(\w)/g, '$1$2');
			break;
		default:
			return { hasError: true, message: 'Unsupported address type' };
	}
	return {
		hasError: false,
		addressRemote: address,
		addressType,
		portRemote: port,
		rawDataIndex: offset,
		waliexiVersion: version,
	};
}

function closeSocket(socket) {
	socket?.close();
}

async function socks5Connect(addressType, addressRemote, portRemote, parsedSocks5Addr) {
	const { username, password, hostname, port } = parsedSocks5Addr;
	const socket = connect({
		hostname,
		port,
	});
	const socksGreeting = new Uint8Array([5, 2, 0, 2]);
	const writer = socket.writable.getWriter();
	await writer.write(socksGreeting);
	console.log('sent socks greeting');
	const reader = socket.readable.getReader();
	const encoder = new TextEncoder();
	let res = (await reader.read()).value;
	if (res[0] !== 0x05) {
		console.log(`socks server version error: ${res[0]} expected: 5`);
		return;
	}
	if (res[1] === 0xff) {
		console.log("no acceptable methods");
		return;
	}
	if (res[1] === 0x02) {
		console.log("socks server needs auth");
		if (!username || !password) {
			console.log("please provide username/password");
			return;
		}
		const authRequest = new Uint8Array([
			1,
			username.length,
			...encoder.encode(username),
			password.length,
			...encoder.encode(password)
		]);
		await writer.write(authRequest);
		res = (await reader.read()).value;
		if (res[0] !== 0x01 || res[1] !== 0x00) {
			console.log("fail to auth socks server");
			return;
		}
	}
	let DSTADDR;
	switch (addressType) {
		case 1:
			DSTADDR = new Uint8Array(
				[1, ...addressRemote.split('.').map(Number)]
			);
			break;
		case 2:
			DSTADDR = new Uint8Array(
				[3, addressRemote.length, ...encoder.encode(addressRemote)]
			);
			break;
		case 3:
			DSTADDR = new Uint8Array(
				[4, ...addressRemote.split(':').flatMap(x => [parseInt(x.slice(0, 2), 16), parseInt(x.slice(2), 16)])]
			);
			break;
		default:
			console.log(`invalid addressType is ${addressType}`);
			return;
	}
	const socksRequest = new Uint8Array([5, 1, 0, ...DSTADDR, portRemote >> 8, portRemote & 0xff]);
	await writer.write(socksRequest);
	console.log('sent socks request');
	res = (await reader.read()).value;
	if (res[1] === 0x00) {
		console.log("socks connection opened");
	} else {
		console.log("fail to open socks connection");
		return;
	}
	writer.releaseLock();
	reader.releaseLock();
	return socket;
}

function socks5AddressParser(address) {
	const [latter, former] = address.split(/@?([\d\[\]a-z.:]+(?::\d+)?)$/i);
	let [username, password] = latter.split(':');
	if (!password) { password = '' };
	let [hostname, port] = former.split(/:((?:\d+)?)$/i);
	if (!port) { port = '443' };
	return { username, password, hostname, port };
}

async function pipeRemoteToWebSocket(remoteSocket, ws, waliexiHeader, retry = null) {
	let headerSent = false;
	let hasIncomingData = false;
	remoteSocket.readable.pipeTo(new WritableStream({
		write(chunk) {
			hasIncomingData = true;
			if (ws.readyState === 1) {
				if (!headerSent) {
					const combined = new Uint8Array(waliexiHeader.byteLength + chunk.byteLength);
					combined.set(new Uint8Array(waliexiHeader), 0);
					combined.set(new Uint8Array(chunk), waliexiHeader.byteLength);
					ws.send(combined.buffer);
					headerSent = true;
				} else {
					ws.send(chunk);
				}
			}
		},
		close() {
			if (!hasIncomingData && retry) {
				retry();
				return;
			}
			if (ws.readyState === 1) {
				ws.close(1000, 'Normal closure');
			}
		},
		abort() {
			closeSocket(remoteSocket);
		}
	})).catch(err => {
		console.error('Data forwarding error:', err);
		closeSocket(remoteSocket);
		if (ws.readyState === 1) {
			ws.close(1011, 'Data transmission error');
		}
	});
}

async function handlewaliexiWebSocket(request, url) {
	const tempurl = decodeURIComponent(url.pathname + url.search);
	const wsPair = new WebSocketPair();
	const [clientWS, serverWS] = Object.values(wsPair);
	serverWS.accept();
	const earlyDataHeader = request.headers.get('sec-websocket-protocol') || '';
	const wsReadable = createWebSocketReadableStream(serverWS, earlyDataHeader);
	let remoteSocket = null;
	wsReadable.pipeTo(new WritableStream({
		async write(chunk) {
			if (remoteSocket) {
				const writer = remoteSocket.writable.getWriter();
				await writer.write(chunk);
				writer.releaseLock();
				return;
			}
			const result = parsewaliexiHeader(chunk, userID);
			if (result.hasError) {
				throw new Error(result.message);
			}
			const waliexiRespHeader = new Uint8Array([result.waliexiVersion[0], 0]);
			const rawClientData = chunk.slice(result.rawDataIndex);
			async function connectAndWrite(address, port) {
				let tcpSocket;
				tcpSocket = connect({
					hostname: address,
					port: port,
				});
				remoteSocket = tcpSocket;
				const writer = tcpSocket.writable.getWriter();
				await writer.write(rawClientData);
				writer.releaseLock();
				return tcpSocket;
			}
			async function retry() {
				try {
					let tcpSocket;
					const enableSocks = tempurl.match(/socks5\s*(?:=|(?::\/\/))\s*([^&]+(?:\d+)?)/i)?.[1];
					if (enableSocks) {
						const Socksip = socks5AddressParser(enableSocks);
						tcpSocket = await socks5Connect(result.addressType, result.addressRemote, result.portRemote, Socksip);
					} else {
						const tmp_ips = tempurl.match(/p(?:rox)?yip\s*=\s*([^&]+(?:\d+)?)/i)?.[1];
						if (tmp_ips) {
							const [latterip, formerport] = tmp_ips.split(/:?(\d{0,5})$/);
							tcpSocket = await connect({
								hostname: latterip,
								port: Number(formerport) || result.portRemote
							});
						} else {
							console.error('Connection failed: No proxy method specified');
						}
					}
					remoteSocket = tcpSocket;
					const writer = tcpSocket.writable.getWriter();
					await writer.write(rawClientData);
					writer.releaseLock();
					tcpSocket.closed.catch(error => {
						console.error('Connection closed with error:', error);
					}).finally(() => {
						if (serverWS.readyState === 1) {
							serverWS.close(1000, 'Connection closed');
						}
					});
					pipeRemoteToWebSocket(tcpSocket, serverWS, waliexiRespHeader, null);
				} catch (err) {
					console.error('Connection failed:', err);
					serverWS.close(1011, 'Connection failed: ' + err.message);
				}
			}
			try {
				const tcpSocket = await connectAndWrite(result.addressRemote, result.portRemote);
				pipeRemoteToWebSocket(tcpSocket, serverWS, waliexiRespHeader, retry);
			} catch (err) {
				console.error('Connection failed:', err);
				serverWS.close(1011, 'Connection failed');
			}
		},
		close() {
			if (remoteSocket) {
				closeSocket(remoteSocket);
			}
		}
	})).catch(err => {
		console.error('WebSocket error:', err);
		closeSocket(remoteSocket);
		serverWS.close(1011, 'Internal error');
	});
	return new Response(null, {
		status: 101,
		webSocket: clientWS,
	});
}

export default {
	async fetch(request) {
		const upgradeHeader = request.headers.get("Upgrade");
		try {
			if (!upgradeHeader || upgradeHeader !== "websocket") {
				return new Response('Hello World!');
			}
			return await handlewaliexiWebSocket(request, new URL(request.url));
		} catch (err) {
			return new Response(err.toString());
		}
	},
};